package com.ac.musicac

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MusicAcApplication : Application() {}
