package com.ac.musicac.data

object Constants {
    const val READ_TIME_OUT = 20L
    const val WRITE_TIME_OUT = 20L
    const val CONNECT_TIME_OUT = 20L
    const val DATABASE_NAME = "musicac-db"
}
