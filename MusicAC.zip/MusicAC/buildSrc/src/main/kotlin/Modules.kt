object Modules {
    const val app = ":app"
    const val domain = ":domain"
    const val data = ":data"
    const val usescases = ":usecases"
    const val testShared = ":testShared"
}