package com.ac.musicac.domain

data class Copyright(
    val text: String
    )
