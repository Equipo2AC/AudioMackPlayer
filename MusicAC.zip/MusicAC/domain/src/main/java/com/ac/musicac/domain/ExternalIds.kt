package com.ac.musicac.domain

data class ExternalIds(
    val upc: String
)
