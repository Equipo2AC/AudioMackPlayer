package com.ac.musicac.domain

data class ExternalUrls(
    val spotify: String
)
