package com.ac.musicac.domain

data class Followers(
    val href: String,
    val total: Int
)
