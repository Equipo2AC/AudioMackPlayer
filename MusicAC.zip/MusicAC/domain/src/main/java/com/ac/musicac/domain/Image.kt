package com.ac.musicac.domain

data class Image(
    val height: Int,
    val url: String,
    val width: Int
)
