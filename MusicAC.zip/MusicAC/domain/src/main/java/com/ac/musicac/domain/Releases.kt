package com.ac.musicac.domain

data class Releases(
    val albums: Albums
)
