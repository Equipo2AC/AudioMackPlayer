package com.ac.musicac.domain

data class Search(
    val albums: Albums?,
    val artists: Artists?
)
