package com.ac.musicac.domain

data class Tracks(
    val items: List<Track>,
    val total: Int
)
