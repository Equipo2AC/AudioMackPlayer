package com.ac.musicac.domain

enum class Type(val value: String)  {
    ALBUM("album"),
    ARTIST("artist")
}
